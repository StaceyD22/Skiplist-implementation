#compile
javac Hw02.java
#begin test steps
java Hw02 H2in-a1.txt >a1St.txt
diff a1St.txt Valid-a1St.txt
java Hw02 H2in-a2.txt >a2St.txt
diff a2St.txt Valid-a2St.txt
java Hw02 H2in-a3.txt >a3St.txt
diff a3St.txt Valid-a3St.txt
java Hw02 H2in-a4.txt >a4St.txt
diff a4St.txt Valid-a4St.txt
java Hw02 H2in-a5.txt >a5St.txt
diff a5St.txt Valid-a5St.txt
java Hw02 H2in-a6.txt >a6St.txt
diff a6St.txt Valid-a6St.txt
java Hw02 H2in-a7.txt >a7St.txt
diff a7St.txt Valid-a7St.txt
java Hw02 H2in-a8.txt >a8St.txt
diff a8St.txt Valid-a8St.txt
java Hw02 H2in-a9.txt >a9St.txt
diff a9St.txt Valid-a9St.txt
java Hw02 H2in-a10.txt >a10St.txt
diff a10St.txt Valid-a10St.txt

